import mysql from 'mysql2/promise';

let pool: mysql.Pool | null = null;

if (process.env.DB_HOST && process.env.DB_USER) {
  try {
    pool = mysql.createPool({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0
    });
    console.log('MySQL Pool Initialized');
  } catch (error) {
    console.error('Failed to initialize MySQL pool:', error);
  }
} else {
  console.log('Database configuration missing. Using mock database.');
}

export const query = async (sql: string, params?: any[]) => {
  if (pool) {
    return pool.execute(sql, params);
  } else {
    // Mock for when no DB config is present
    console.log('Mock DB Query:', sql, params);
    return [[], []];
  }
};

export const initDb = async () => {
  if (!pool) return;
  
  const queries = [
    `CREATE TABLE IF NOT EXISTS users (
      id VARCHAR(36) PRIMARY KEY,
      email VARCHAR(255) UNIQUE NOT NULL,
      password VARCHAR(255) NOT NULL,
      role ENUM('user', 'admin') DEFAULT 'user',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    `CREATE TABLE IF NOT EXISTS credits (
      user_id VARCHAR(36) PRIMARY KEY,
      balance INT DEFAULT 5,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )`,
    `CREATE TABLE IF NOT EXISTS uploads (
      id VARCHAR(36) PRIMARY KEY,
      user_id VARCHAR(36) NOT NULL,
      filename VARCHAR(255) NOT NULL,
      original_name VARCHAR(255) NOT NULL,
      status ENUM('pending', 'processing', 'completed', 'failed') DEFAULT 'pending',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )`,
    `CREATE TABLE IF NOT EXISTS renders (
      id VARCHAR(36) PRIMARY KEY,
      upload_id VARCHAR(36) NOT NULL,
      user_id VARCHAR(36) NOT NULL,
      preset VARCHAR(100) NOT NULL,
      output_filename VARCHAR(255) NOT NULL,
      duration FLOAT,
      status ENUM('queued', 'rendering', 'completed', 'failed') DEFAULT 'queued',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (upload_id) REFERENCES uploads(id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )`,
    // add more as needed...
  ];

  try {
    for (const q of queries) {
      await pool.query(q);
    }
    console.log('Database tables initialized');
  } catch (error) {
    console.error('Failed to init DB tables:', error);
  }
};
