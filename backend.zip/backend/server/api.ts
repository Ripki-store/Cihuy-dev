import express from 'express';
import multer from 'multer';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import fs from 'fs';
import { query } from './db.ts';
import { GoogleGenAI } from '@google/genai';
import { processVideo } from './processing.ts';

const router = express.Router();
const uploadQueue: any[] = [];

// Multer config for video upload
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(process.cwd(), 'uploads'));
  },
  filename: (req, file, cb) => {
    const defaultExt = '.mp4';
    const originalExt = path.extname(file.originalname) || defaultExt;
    cb(null, `${uuidv4()}${originalExt}`);
  }
});
const upload = multer({ 
  storage,
  limits: { fileSize: 500 * 1024 * 1024 }, // 500MB
  fileFilter: (req, file, cb) => {
    if (['video/mp4', 'video/webm', 'video/quicktime'].includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type'));
    }
  }
});

// Mock Auth logic
router.post('/auth/login', async (req, res) => {
  res.json({ token: 'mock-jwt-token', user: { id: '1', role: 'admin' } });
});

router.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

router.post('/upload', upload.single('video'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No video provided' });
    }
    
    const uploadId = uuidv4();
    const preset = req.body.preset || 'default';
    
    // Save to database
    await query('INSERT INTO uploads (id, user_id, filename, original_name) VALUES (?, ?, ?, ?)', 
      [uploadId, '1', req.file.filename, req.file.originalname]);
    
    const renderId = uuidv4();
    const outputFilename = `${renderId}.mp4`;
    
    await query('INSERT INTO renders (id, upload_id, user_id, preset, output_filename) VALUES (?, ?, ?, ?, ?)',
      [renderId, uploadId, '1', preset, outputFilename]);

    // Push to processing queue (async)
    processVideo(req.file.filename, outputFilename, preset, renderId).catch(async (e) => {
      console.error('Processing error:', e);
      await query('UPDATE renders SET status = ? WHERE id = ?', ['failed', renderId]);
    });
    
    res.json({ success: true, uploadId, renderId });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/renders', async (req, res) => {
  // Mock results if no DB, but we want it working
  try {
    const [rows]: any = await query('SELECT * FROM renders ORDER BY created_at DESC LIMIT 10');
    // If empty array, return mock active render for UI demo
    if (rows.length === 0) {
      res.json([{id: 'demo-1', status: 'completed', output_filename: 'demo.mp4', preset: 'MLBB Hyper Edit', created_at: new Date()}]);
      return;
    }
    res.json(rows);
  } catch(e) {
    res.json([]);
  }
});

export default router;
