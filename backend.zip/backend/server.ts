import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import apiRouter from './server/api.ts';
import { initDb } from './server/db.ts';

const PORT = 3000;

// Setup directories
const dirs = ['uploads', 'temp', 'renders'];
dirs.forEach(dir => {
  const dirPath = path.join(process.cwd(), dir);
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
});

async function startServer() {
  const app = express();
  
  app.use(express.json());
  
  // Initialize Database Connect
  await initDb();
  
  // API routes
  app.use('/api', apiRouter);

  // Serve created renders as static
  app.use('/downloads', express.static(path.join(process.cwd(), 'renders')));

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer().catch(console.error);
