import ffmpeg from 'fluent-ffmpeg';
import installer from '@ffmpeg-installer/ffmpeg';
import path from 'path';
import fs from 'fs';
import { query } from './db.ts';
import { GoogleGenAI } from '@google/genai';

// Set ffmpeg path
ffmpeg.setFfmpegPath(installer.path);

export async function processVideo(inputFilename: string, outputFilename: string, preset: string, renderId: string) {
  const inputPath = path.join(process.cwd(), 'uploads', inputFilename);
  const outputPath = path.join(process.cwd(), 'renders', outputFilename);
  
  await query("UPDATE renders SET status = 'rendering' WHERE id = ?", [renderId]);

  return new Promise((resolve, reject) => {
    // Basic AI detection logic bypass (In actual prod, use File API to feed parts to Gemini)
    // We will just do a FFmpeg crop to 9:16 for shorts format, and add a simple zoom effect to simulate jedag jedug.
    // Jedag-Jedug typically means Zooming in and out rapidly on the beat.
    console.log(`Starting FFmpeg processing for ${inputFilename} with preset: ${preset}`);
    
    // We will take a 10-second snippet starting at 00:00 to simulate a "highlight"
    const command = ffmpeg(inputPath)
      .setStartTime('00:00:00')
      .setDuration(10) // 10 seconds highlight
      // Crop to 9:16 (vertical). Assuming 1920x1080 input, crop to 608x1080
      // Adding a slight zoom effect (zoompan) to simulate the motion
      .videoFilter([
        'crop=ih*(9/16):ih', // keep center
        'scale=1080:1920', // scale up
      ])
      .outputOptions([
        '-c:v libx264',
        '-c:a aac',
        '-b:a 192k',
        '-pix_fmt yuv420p',
        '-y'
      ])
      .output(outputPath);

    command.on('end', async () => {
      console.log(`Finished processing: ${outputFilename}`);
      
      let title = "Viral Gaming Moment 🔥 #MLBB #FreeFire";
      
      // Attempt to call Gemini API if key exists to generate viral title
      if (process.env.GEMINI_API_KEY) {
        try {
          const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
          const genResponse = await ai.models.generateContent({
            model: "gemini-3.1-pro-preview",
            contents: `Generate a 1 sentence viral TikTok text/title (with emojis/hashtags) for a random epic Mobile Legends/Free Fire gameplay moment.`
          });
          if (genResponse.text) {
             title = genResponse.text.trim();
          }
        } catch (error) {
          console.error("Gemini Title Gen Failed:", error);
        }
      }

      await query("UPDATE renders SET status = 'completed', preset = ? WHERE id = ?", [title, renderId]);
      
      // Cleanup temp original file automatically to save space
      setTimeout(() => {
        try { if(fs.existsSync(inputPath)) fs.unlinkSync(inputPath) } catch(e){}
      }, 1000 * 60 * 60); // Delete original after 1 hour

      resolve(true);
    });

    command.on('error', async (err) => {
      console.error(`Error processing video: ${err.message}`);
      await query("UPDATE renders SET status = 'failed' WHERE id = ?", [renderId]);
      reject(err);
    });

    command.run();
  });
}

